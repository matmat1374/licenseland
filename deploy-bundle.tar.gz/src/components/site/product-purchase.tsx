"use client";

import { useState } from "react";
import { ShoppingCart, Zap, Check, ShieldCheck, RefreshCw, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/store/cart";
import { calcDiscountPercent, toToman } from "@/lib/format";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import type { ProductListItem } from "@/lib/queries";
import { cn } from "@/lib/utils";

export function ProductPurchase({ product }: { product: ProductListItem }) {
  const add = useCart((s) => s.add);
  const openCart = useCart((s) => s.open);
  const router = useRouter();
  const [added, setAdded] = useState(false);

  const discount = calcDiscountPercent(product.price, product.discountPrice);
  const price = product.discountPrice ?? product.price;
  const inStock = product._stock > 0;

  function handleAdd() {
    if (!inStock) return toast.error("این محصول فعلاً ناموجود است");
    add({
      id: product.id,
      slug: product.slug,
      title: product.title,
      price: product.price,
      discountPrice: product.discountPrice,
      image: product.image,
      duration: product.duration,
    });
    setAdded(true);
    toast.success("به سبد خرید اضافه شد");
    setTimeout(() => setAdded(false), 1500);
  }

  function handleBuyNow() {
    if (!inStock) return toast.error("این محصول فعلاً ناموجود است");
    add(
      {
        id: product.id,
        slug: product.slug,
        title: product.title,
        price: product.price,
        discountPrice: product.discountPrice,
        image: product.image,
        duration: product.duration,
      },
      1,
      false
    );
    router.push("/checkout");
  }

  return (
    <div className="flex flex-col gap-4">
      {/* price box */}
      <div className="rounded-2xl border bg-card p-5">
        <div className="mb-3 flex items-end justify-between gap-2">
          <div>
            {discount > 0 && (
              <div className="mb-1 flex items-center gap-2">
                <Badge className="bg-rose-500 text-white hover:bg-rose-500">{discount}٪ تخفیف</Badge>
                <span className="text-sm text-muted-foreground line-through">
                  {toToman(product.price)}
                </span>
              </div>
            )}
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-black text-primary">{toToman(price)}</span>
              <span className="text-sm text-muted-foreground">تومان</span>
            </div>
          </div>
          {product.duration && (
            <Badge variant="secondary" className="gap-1">
              <Clock className="h-3 w-3" />
              {product.duration}
            </Badge>
          )}
        </div>

        {/* Stock & Guarantee assurance */}
        <div className="mb-4 rounded-xl border border-primary/20 bg-primary/5 p-3 text-xs space-y-2">
          {inStock ? (
            <div className="flex items-center gap-1.5 font-bold text-emerald-600 dark:text-emerald-400">
              <Zap className="h-4 w-4 fill-current text-emerald-500" />
              <span>موجود در انبار — تحویل آنی و خودکار پس از پرداخت</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 font-bold text-rose-500">
              <span>در حال حاضر ناموجود</span>
            </div>
          )}

          <div className="text-[11px] font-medium text-muted-foreground flex items-center gap-1.5 pt-1.5 border-t border-primary/10">
            <ShieldCheck className="h-4 w-4 text-primary shrink-0" />
            <span>لایسنس ۱۰۰٪ اورجینال با پشتیبانی ۲۴ ساعته</span>
          </div>
        </div>

        {/* actions */}
        <div className="flex flex-col gap-2">
          <Button
            size="lg"
            onClick={handleBuyNow}
            disabled={!inStock}
            className="h-12 gap-2 text-base shadow-lg shadow-primary/20"
          >
            <Zap className="h-4 w-4" />
            خرید و پرداخت آنی
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={handleAdd}
            disabled={!inStock}
            className={cn("h-12 gap-2 text-base", added && "border-emerald-500 text-emerald-600")}
          >
            {added ? <Check className="h-4 w-4" /> : <ShoppingCart className="h-4 w-4" />}
            {added ? "اضافه شد" : "افزودن به سبد"}
          </Button>
        </div>
      </div>

      {/* guarantees */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { icon: Zap, label: "تحویل آنی" },
          { icon: ShieldCheck, label: "ضمانت اصالت" },
          { icon: RefreshCw, label: "تعویض ۷ روزه" },
        ].map((g) => (
          <div key={g.label} className="flex flex-col items-center gap-1.5 rounded-xl border bg-card p-3 text-center">
            <g.icon className="h-5 w-5 text-primary" />
            <span className="text-[11px] font-medium">{g.label}</span>
          </div>
        ))}
      </div>
      {/* sticky mobile buy bar */}
      <div className="fixed bottom-[68px] left-0 right-0 z-40 flex items-center justify-between gap-4 border-t border-white/10 bg-background/85 px-4 py-3 backdrop-blur-xl shadow-[0_-10px_30px_rgba(0,0,0,0.3)] md:hidden pb-safe">
        <div className="flex flex-col">
          {discount > 0 && (
            <span className="text-[10px] text-muted-foreground line-through decoration-destructive/50">
              {toToman(product.price)}
            </span>
          )}
          <div className="flex items-baseline gap-1">
            <span className="text-base font-black text-foreground">{toToman(price)}</span>
            <span className="text-[10px] text-muted-foreground">تومان</span>
          </div>
        </div>
        <Button
          size="sm"
          onClick={handleBuyNow}
          disabled={!inStock}
          className="h-10 shrink-0 gap-1.5 rounded-xl px-6 font-bold shadow-lg shadow-primary/20 text-white"
        >
          <Zap className="h-4 w-4 fill-current" />
          خرید آنی
        </Button>
      </div>
    </div>
  );
}
