import { Activity, AlertTriangle, CheckCircle, Database, LayoutDashboard, Terminal } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export const metadata = {
  title: "مانیتورینگ و لاگ‌ها | لایسنس‌لند",
};

async function fetchLogs() {
  const url = process.env.OPENOBSERVE_URL;
  const org = process.env.OPENOBSERVE_ORG || "default";
  const stream = process.env.OPENOBSERVE_STREAM || "liceno_logs";
  const auth = process.env.OPENOBSERVE_AUTH;

  if (!url || !auth) {
    return { configured: false, logs: null, error: null };
  }

  try {
    const endpoint = `${url}/api/${org}/${stream}/_search`;
    
    // Simple query to fetch recent logs
    const query = {
      query: {
        sql: `SELECT * FROM ${stream} ORDER BY _timestamp DESC LIMIT 100`,
        start_time: new Date(Date.now() - 24 * 60 * 60 * 1000).getTime() * 1000, // 24 hours
        end_time: new Date().getTime() * 1000,
        from: 0,
        size: 100
      }
    };

    const res = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": auth.startsWith("Basic ") || auth.startsWith("Bearer ") ? auth : `Basic ${auth}`,
      },
      body: JSON.stringify(query),
      cache: "no-store"
    });

    if (!res.ok) {
      throw new Error(`OpenObserve API error: ${res.status} ${res.statusText}`);
    }

    const data = await res.json();
    return { configured: true, logs: data.hits || [], error: null };
  } catch (err: any) {
    return { configured: true, logs: null, error: err.message || "Failed to fetch logs" };
  }
}

export default async function LogsPage() {
  const { configured, logs, error } = await fetchLogs();

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">مانیتورینگ و لاگ‌ها</h1>
          <p className="text-muted-foreground mt-1">
            مشاهده رویدادهای سیستم، خطاها و آمار ارتباط با سرویس‌های خارجی
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">وضعیت OpenObserve</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {configured ? (
                error ? (
                  <span className="text-red-500">خطای اتصال</span>
                ) : (
                  <span className="text-emerald-500">متصل</span>
                )
              ) : (
                <span className="text-muted-foreground">غیرفعال</span>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {configured ? (error ? error : "لاگ‌ها به سرور ارسال می‌شوند") : "متغیرهای محیطی تنظیم نشده‌اند"}
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">همه لاگ‌ها</TabsTrigger>
          <TabsTrigger value="errors">خطاها</TabsTrigger>
          <TabsTrigger value="events">رویدادها</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>لاگ‌های سیستمی</CardTitle>
              <CardDescription>آخرین رکوردهای ثبت شده در سیستم لاگ</CardDescription>
            </CardHeader>
            <CardContent>
              {configured && error ? (
                <div className="flex flex-col items-center justify-center p-8 text-center bg-muted/50 rounded-lg border border-dashed">
                  <AlertTriangle className="h-10 w-10 text-red-500 mb-2" />
                  <p className="font-medium">خطا در دریافت لاگ‌ها از سرور</p>
                  <p className="text-sm text-muted-foreground mt-1">{error}</p>
                </div>
              ) : !configured ? (
                <div className="flex flex-col items-center justify-center p-8 text-center bg-muted/50 rounded-lg border border-dashed">
                  <Terminal className="h-10 w-10 text-muted-foreground mb-2" />
                  <p className="font-medium">سرویس OpenObserve تنظیم نشده است</p>
                  <p className="text-sm text-muted-foreground mt-1 mb-4">
                    برای فعال‌سازی مانیتورینگ پیشرفته، متغیرهای محیطی مربوطه را در فایل <code className="text-xs bg-muted p-1 rounded">.env</code> قرار دهید.
                  </p>
                  <div className="text-left bg-black text-emerald-400 p-4 rounded-md text-xs font-mono w-full max-w-md overflow-x-auto">
                    OPENOBSERVE_URL="https://api.openobserve.ai"<br/>
                    OPENOBSERVE_ORG="default"<br/>
                    OPENOBSERVE_STREAM="liceno_logs"<br/>
                    OPENOBSERVE_AUTH="Basic BASE64_TOKEN"
                  </div>
                </div>
              ) : (
                <ScrollArea className="h-[500px] w-full rounded-md border p-4">
                  {logs && logs.length > 0 ? (
                    <div className="space-y-4">
                      {logs.map((log: any, i: number) => (
                        <div key={i} className="flex flex-col gap-2 border-b pb-4 last:border-0">
                          <div className="flex items-center gap-2">
                            <Badge variant={log.level === 'ERROR' ? 'destructive' : log.level === 'WARN' ? 'secondary' : 'default'}>
                              {log.level || 'INFO'}
                            </Badge>
                            <span className="text-xs text-muted-foreground">{new Date(log._timestamp / 1000 || log.timestamp).toLocaleString('fa-IR')}</span>
                            {log.event && <Badge variant="outline" className="text-xs">{log.event}</Badge>}
                          </div>
                          <p className="text-sm font-medium">{log.message}</p>
                          {(log.error || log.metadata) && (
                            <pre className="text-xs bg-muted p-2 rounded-md overflow-x-auto mt-1">
                              {JSON.stringify({ error: log.error, metadata: log.metadata }, null, 2)}
                            </pre>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                      هیچ لاگی یافت نشد.
                    </div>
                  )}
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="errors" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>خطاهای سیستم</CardTitle>
            </CardHeader>
            <CardContent>
              {/* Similar logic but filtered for ERROR */}
              <div className="text-center p-8 text-muted-foreground text-sm border border-dashed rounded-lg">
                در حال حاضر فقط نمایش همه لاگ‌ها پیاده‌سازی شده است.
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="events" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>رویدادهای کسب و کار</CardTitle>
            </CardHeader>
            <CardContent>
               {/* Similar logic but filtered for events */}
               <div className="text-center p-8 text-muted-foreground text-sm border border-dashed rounded-lg">
                در حال حاضر فقط نمایش همه لاگ‌ها پیاده‌سازی شده است.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
