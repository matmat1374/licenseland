import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Starting custom DB enrichment...');
  let updatedCount = 0;

  const allProducts = await prisma.product.findMany();

  for (const p of allProducts) {
    let needsUpdate = false;
    let newTitle = p.title;
    let newBrand = p.brand;
    let newCategory = p.category;
    let newDuration = p.duration;
    
    // Fix Gemini 18 months
    if (newTitle.includes('جمینای پرو ۱۸ ماهه') || newTitle.includes('جمنای پرو ۱۸ ماهه')) {
      if (newDuration === '۸ ماهه') {
        newDuration = '۱۸ ماهه';
        needsUpdate = true;
      }
    }

    // PUBG UC
    if (newTitle === 'UC 60') {
      newTitle = 'یوسی پابجی موبایل - ۶۰ یوسی (PUBG Mobile UC)';
      newBrand = 'PUBG Mobile';
      newCategory = 'gaming';
      needsUpdate = true;
    }
    if (newTitle === 'UC 60 + 600') {
      newTitle = 'یوسی پابجی موبایل - ۶۶۰ یوسی (PUBG Mobile UC 600 + 60)';
      newBrand = 'PUBG Mobile';
      newCategory = 'gaming';
      needsUpdate = true;
    }

    // Telegram Stars
    if (newTitle === 'Telegram Stars 50') {
      newTitle = 'استارز تلگرام - ۵۰ عدد (Telegram Stars)';
      newBrand = 'Telegram';
      newCategory = 'social';
      needsUpdate = true;
    }
    if (newTitle === 'Telegram Stars 100') {
      newTitle = 'استارز تلگرام - ۱۰۰ عدد (Telegram Stars)';
      newBrand = 'Telegram';
      newCategory = 'social';
      needsUpdate = true;
    }
    if (newTitle === 'Telegram Stars 1000') {
      newTitle = 'استارز تلگرام - ۱۰۰۰ عدد (Telegram Stars)';
      newBrand = 'Telegram';
      newCategory = 'social';
      needsUpdate = true;
    }

    // Notion Business
    if (newTitle.startsWith('Slot Notion Business has an official AI with a full 1-')) {
      newTitle = 'اسلات نوشن بیزینس همراه با هوش مصنوعی (Notion Business + AI) - ۱ ساله';
      newDuration = '۱ ساله';
      needsUpdate = true;
    }
    if (newTitle.startsWith('Slot Notion Business has an official AI with a full 3-')) {
      newTitle = 'اسلات نوشن بیزینس همراه با هوش مصنوعی (Notion Business + AI) - ۳ ماهه';
      newDuration = '۳ ماهه';
      needsUpdate = true;
    }

    // Figma
    if (newTitle === 'Figma Pro Edu 2Y') {
      newTitle = 'اکانت فیگما پرو ۲ ساله دانشجویی (Figma Pro Edu 2Y)';
      newDuration = '۲ ساله';
      needsUpdate = true;
    }
    if (newTitle === 'Figma Pro Education 2 Years Year full') {
      newTitle = 'اکانت فیگما پرو ۲ ساله نسخه کامل با گارانتی تمدید (Figma Pro Education 2Y Full)';
      newDuration = '۲ ساله';
      needsUpdate = true;
    }

    // Google Play Gift Card
    if (newTitle.includes('Google Play Gift Card 50$ (US) - Google Play (US) -')) {
      newTitle = 'گیفت کارت ۵۰ دلاری گوگل پلی آمریکا (Google Play US 50$)';
      newDuration = 'گیفت کارت $50';
      needsUpdate = true;
    }

    if (needsUpdate) {
      await prisma.product.update({
        where: { id: p.id },
        data: {
          title: newTitle,
          brand: newBrand,
          category: newCategory,
          duration: newDuration
        }
      });
      updatedCount++;
      console.log(`Updated product: ${p.title} -> ${newTitle}`);
    }
  }

  // Also fix all durations dynamically with the new regex
  const extractDuration = (text) => {
    if (!text) return null;
    const match = text.match(/([۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩\d]+) (ماهه|ساله|روزه)/);
    if (match) return match[0];
    return null;
  };

  const updatedProducts = await prisma.product.findMany();
  for (const p of updatedProducts) {
    const extracted = extractDuration(p.title);
    if (extracted && p.duration !== extracted) {
      await prisma.product.update({
        where: { id: p.id },
        data: { duration: extracted }
      });
      updatedCount++;
      console.log(`Fixed duration for ${p.title}: ${p.duration} -> ${extracted}`);
    }
  }

  console.log(`Finished custom DB enrichment. Total updated: ${updatedCount}`);
}

main()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
